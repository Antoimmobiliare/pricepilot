"""
PricePilot dashboard authentication.

Default mode is local SQLite auth so the app can be tested without external
services. Supabase is used automatically when SUPABASE_URL and SUPABASE_ANON_KEY
are configured. Set PRICEPILOT_AUTH_MODE=disabled only for explicit dev bypass.
"""
from __future__ import annotations

import hashlib
import html as _html
import os
import secrets
from datetime import datetime

import streamlit as st

from pricepilot.core.database import (
    create_account,
    create_user,
    get_user_by_email,
    update_user,
)
from pricepilot.core.plans import get_plan, normalize_plan
from pricepilot.services.account_service import create_account_owner

_KEY_USER = "pp_auth_user"
_KEY_SESSION = "pp_auth_session"
_KEY_PUBLIC_VIEW = "pp_public_view"
_KEY_SELECTED_PLAN = "pp_selected_plan"

PUBLIC_VIEWS = {"landing", "login", "register", "forgot"}
PLAN_ORDER = ("free", "plus", "pro")


def _get_client():
    url = os.environ.get("SUPABASE_URL", "").strip()
    key = os.environ.get("SUPABASE_ANON_KEY", "").strip()
    if not url or not key:
        return None
    try:
        from supabase import create_client
        return create_client(url, key)
    except Exception:
        return None


def get_current_user() -> dict | None:
    return st.session_state.get(_KEY_USER)


def get_current_account_id() -> int:
    user = get_current_user() or {}
    try:
        return max(1, int(user.get("account_id") or 1))
    except (TypeError, ValueError):
        return 1


def logout():
    client = _get_client()
    if client:
        try:
            client.auth.sign_out()
        except Exception:
            pass
    st.session_state.pop(_KEY_USER, None)
    st.session_state.pop(_KEY_SESSION, None)


def render_logout_button():
    user = get_current_user()
    if not user:
        return
    email = user.get("email", "")
    _, col_btn = st.columns([8, 2])
    with col_btn:
        st.markdown(
            f"<div style='text-align:right;font-size:0.78rem;color:#6b7280;"
            f"padding:4px 0 2px;'>{email}</div>",
            unsafe_allow_html=True,
        )
        if st.button("Esci", key="pp_logout_btn", use_container_width=True):
            logout()
            st.rerun()


def _go_public(view: str, plan: str | None = None) -> None:
    st.session_state[_KEY_PUBLIC_VIEW] = view if view in PUBLIC_VIEWS else "landing"
    if plan:
        st.session_state[_KEY_SELECTED_PLAN] = normalize_plan(plan)
    st.rerun()


def _selected_plan() -> str:
    return normalize_plan(st.session_state.get(_KEY_SELECTED_PLAN, "free"))


def require_auth() -> bool:
    if get_current_user():
        return True

    auth_mode = os.environ.get("PRICEPILOT_AUTH_MODE", "local").strip().lower()
    if auth_mode == "disabled":
        st.sidebar.warning(
            "Autenticazione disabilitata. Stai usando PRICEPILOT_AUTH_MODE=disabled.",
            icon="!",
        )
        return True

    client = _get_client()
    _render_auth_page(client)
    return False


def _render_auth_page(client):
    _inject_public_css()
    view = st.session_state.get(_KEY_PUBLIC_VIEW, "landing")
    if view not in PUBLIC_VIEWS:
        view = "landing"
    if view == "landing":
        _render_landing_page()
    else:
        _render_auth_panel(client, view)


def _inject_public_css():
    st.markdown("""
    <style>
    [data-testid="stSidebar"], [data-testid="collapsedControl"] { display:none !important; }
    #MainMenu, footer { visibility:hidden; }
    .block-container { max-width:1180px; padding-top:1.2rem; padding-bottom:3rem; }
    .pp-nav { display:flex; align-items:center; justify-content:space-between;
              border:1px solid #e5e7eb; border-radius:16px; padding:12px 16px;
              background:rgba(255,255,255,.96); position:sticky; top:12px; z-index:10;
              box-shadow:0 8px 26px rgba(15,23,42,.06); }
    .pp-logo { display:flex; align-items:center; gap:10px; font-weight:900; color:#0f172a; font-size:1.05rem; }
    .pp-logo-mark { width:30px; height:30px; border-radius:9px; background:#0f766e;
                    color:white; display:inline-flex; align-items:center; justify-content:center; font-weight:900; }
    .pp-nav-links { display:flex; align-items:center; justify-content:center; gap:22px; font-size:.88rem; }
    .pp-nav-links a { color:#475569; text-decoration:none; font-weight:650; }
    .pp-nav-links a:hover { color:#0f766e; }
    .pp-eyebrow { display:inline-flex; align-items:center; gap:8px; color:#0f766e; background:#ecfdf5;
                  border:1px solid #bbf7d0; border-radius:999px; padding:6px 11px;
                  font-size:.78rem; font-weight:800; letter-spacing:.03em; }
    .pp-hero { padding:72px 0 46px; }
    .pp-hero h1 { font-size:3.55rem; line-height:1.02; letter-spacing:0; color:#0f172a; margin:20px 0 18px; font-weight:950; }
    .pp-hero p { font-size:1.08rem; line-height:1.7; color:#475569; max-width:650px; margin-bottom:26px; }
    .pp-proof-row { display:flex; gap:14px; flex-wrap:wrap; margin-top:22px; color:#475569; font-size:.88rem; }
    .pp-proof { border:1px solid #e5e7eb; border-radius:999px; padding:8px 12px; background:white; }
    .pp-mockup { background:#0f172a; border-radius:24px; padding:18px; color:white;
                 box-shadow:0 26px 70px rgba(15,23,42,.24); border:1px solid rgba(255,255,255,.10); }
    .pp-mock-top { display:flex; justify-content:space-between; align-items:center; padding:4px 4px 14px; }
    .pp-dot-row span { display:inline-block; width:9px; height:9px; border-radius:99px; margin-right:5px; background:#64748b; }
    .pp-mock-grid { display:grid; grid-template-columns:1.1fr .9fr; gap:12px; }
    .pp-panel { background:#111827; border:1px solid rgba(255,255,255,.08); border-radius:14px; padding:14px; }
    .pp-panel-title { font-size:.72rem; color:#94a3b8; text-transform:uppercase; font-weight:800; letter-spacing:.08em; margin-bottom:10px; }
    .pp-calendar { display:grid; grid-template-columns:repeat(4,1fr); gap:8px; }
    .pp-day { background:#1f2937; border-radius:10px; padding:9px 8px; min-height:54px; }
    .pp-day strong { display:block; color:#f8fafc; font-size:.92rem; }
    .pp-day span { color:#94a3b8; font-size:.74rem; }
    .pp-day.hot { background:#0f766e; }
    .pp-day.warn { background:#b45309; }
    .pp-bars { display:flex; align-items:end; gap:8px; height:150px; padding-top:10px; }
    .pp-bar { flex:1; border-radius:9px 9px 4px 4px; background:#38bdf8; min-height:28px; }
    .pp-bar:nth-child(2n) { background:#14b8a6; }
    .pp-bar:nth-child(3n) { background:#f97316; }
    .pp-kpi-row { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; margin-top:12px; }
    .pp-kpi { background:#f8fafc; color:#0f172a; border-radius:12px; padding:12px; }
    .pp-kpi b { display:block; font-size:1.2rem; }
    .pp-kpi span { color:#64748b; font-size:.72rem; }
    .pp-section { padding:56px 0; }
    .pp-section h2 { color:#0f172a; font-size:2.15rem; font-weight:900; letter-spacing:0; margin-bottom:10px; }
    .pp-section-lead { color:#64748b; font-size:1rem; max-width:720px; line-height:1.7; margin-bottom:28px; }
    .pp-card { height:100%; background:#ffffff; border:1px solid #e5e7eb; border-radius:8px;
               padding:20px; box-shadow:0 10px 30px rgba(15,23,42,.045); transition:all .18s ease; }
    .pp-card:hover { transform:translateY(-3px); border-color:#99f6e4; box-shadow:0 18px 42px rgba(15,23,42,.09); }
    .pp-icon { width:38px; height:38px; border-radius:10px; display:flex; align-items:center; justify-content:center;
               background:#ecfeff; color:#0f766e; font-weight:900; margin-bottom:14px; border:1px solid #ccfbf1; }
    .pp-card h3 { font-size:1rem; color:#0f172a; font-weight:850; margin:0 0 8px; }
    .pp-card p { color:#64748b; font-size:.9rem; line-height:1.58; margin:0; }
    .pp-step { background:white; border:1px solid #e5e7eb; border-radius:8px; padding:24px;
               height:100%; box-shadow:0 10px 30px rgba(15,23,42,.045); }
    .pp-step-num { width:34px; height:34px; border-radius:999px; background:#0f172a; color:white;
                   display:flex; align-items:center; justify-content:center; font-weight:900; margin-bottom:14px; }
    .pp-price { position:relative; height:100%; background:white; border:1px solid #e5e7eb; border-radius:8px;
                padding:24px; box-shadow:0 10px 30px rgba(15,23,42,.045); }
    .pp-price.recommended { border:2px solid #0f766e; box-shadow:0 18px 50px rgba(15,118,110,.16); }
    .pp-badge { position:absolute; top:14px; right:14px; background:#0f766e; color:white; border-radius:999px;
                padding:5px 10px; font-size:.72rem; font-weight:850; }
    .pp-price-name { font-size:1.1rem; font-weight:900; color:#0f172a; margin-bottom:8px; }
    .pp-price-value { font-size:2.1rem; font-weight:950; color:#0f172a; margin:10px 0; }
    .pp-price-desc { color:#64748b; min-height:48px; font-size:.9rem; line-height:1.55; }
    .pp-feature-list { margin:18px 0 0; padding:0; list-style:none; color:#334155; font-size:.88rem; line-height:2; }
    .pp-feature-list li:before { content:""; display:inline-block; width:7px; height:7px; border-radius:99px;
                                 background:#0f766e; margin-right:9px; vertical-align:middle; }
    .pp-auth-wrap { min-height:88vh; display:flex; align-items:center; justify-content:center; padding:34px 0; }
    .pp-auth-card { width:100%; max-width:520px; background:white; border:1px solid #e5e7eb; border-radius:18px;
                    padding:28px; box-shadow:0 22px 70px rgba(15,23,42,.12); }
    .pp-auth-title { color:#0f172a; font-size:1.55rem; font-weight:950; margin:8px 0; }
    .pp-auth-copy { color:#64748b; font-size:.92rem; line-height:1.6; margin-bottom:18px; }
    .pp-plan-pill { display:inline-flex; align-items:center; gap:8px; background:#ecfdf5; color:#0f766e;
                    border:1px solid #bbf7d0; border-radius:999px; padding:6px 10px; font-size:.78rem; font-weight:850; }
    @media (max-width: 760px) {
      .pp-nav { position:relative; top:auto; align-items:flex-start; gap:12px; }
      .pp-nav-links { display:none; }
      .pp-hero { padding:38px 0 26px; }
      .pp-hero h1 { font-size:2.35rem; }
      .pp-mock-grid, .pp-kpi-row { grid-template-columns:1fr; }
    }
    </style>
    """, unsafe_allow_html=True)


def _render_public_nav():
    logo_col, links_col, login_col, cta_col = st.columns([2.0, 4.2, 1.0, 1.35])
    with logo_col:
        st.markdown(
            '<div class="pp-logo"><span class="pp-logo-mark">P</span><span>PricePilot</span></div>',
            unsafe_allow_html=True,
        )
    with links_col:
        st.markdown(
            '<div class="pp-nav-links">'
            '<a href="#funzionalita">Funzionalita</a>'
            '<a href="#prezzi">Prezzi</a>'
            '<a href="#faq">FAQ</a>'
            '</div>',
            unsafe_allow_html=True,
        )
    with login_col:
        if st.button("Login", key="public_nav_login", use_container_width=True):
            _go_public("login")
    with cta_col:
        if st.button("Inizia Gratis", key="public_nav_signup", use_container_width=True, type="primary"):
            _go_public("register", "free")


def _render_landing_page():
    st.markdown('<div class="pp-nav">', unsafe_allow_html=True)
    _render_public_nav()
    st.markdown('</div>', unsafe_allow_html=True)

    hero_left, hero_right = st.columns([1.05, 0.95], gap="large")
    with hero_left:
        st.markdown(
            '<section class="pp-hero">'
            '<span class="pp-eyebrow">Revenue management per host e property manager</span>'
            '<h1>Dynamic Pricing Intelligente per Affitti Brevi</h1>'
            '<p>PricePilot analizza mercato, competitor e occupazione per ottimizzare '
            'automaticamente i prezzi e aumentare i ricavi.</p>'
            '</section>',
            unsafe_allow_html=True,
        )
        c1, c2 = st.columns([1, 1])
        with c1:
            if st.button("Inizia Gratis", key="hero_start_free", use_container_width=True, type="primary"):
                _go_public("register", "free")
        with c2:
            if st.button("Guarda Demo", key="hero_demo", use_container_width=True):
                st.session_state["pp_show_demo_note"] = True
                st.rerun()
        if st.session_state.get("pp_show_demo_note"):
            st.info("La demo e il mockup qui a destra mostrano il flusso: calendario, analytics e decisioni prezzo.")
        st.markdown(
            '<div class="pp-proof-row">'
            '<span class="pp-proof">Guardrail sui prezzi</span>'
            '<span class="pp-proof">Telegram approval</span>'
            '<span class="pp-proof">Multi proprieta</span>'
            '</div>',
            unsafe_allow_html=True,
        )
    with hero_right:
        _render_dashboard_mockup()

    _render_features_section()
    _render_how_it_works_section()
    _render_pricing_section()
    _render_faq_section()
    st.markdown(
        '<div style="border-top:1px solid #e5e7eb;margin-top:34px;padding:24px 0;color:#64748b;'
        'font-size:.86rem;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">'
        '<span>PricePilot</span><span>Dynamic Pricing per Affitti Brevi</span></div>',
        unsafe_allow_html=True,
    )


def _render_dashboard_mockup():
    st.markdown("""
    <div class="pp-mockup">
      <div class="pp-mock-top">
        <div class="pp-dot-row"><span></span><span></span><span></span></div>
        <div style="color:#cbd5e1;font-size:.78rem;font-weight:800">Dashboard live</div>
      </div>
      <div class="pp-mock-grid">
        <div class="pp-panel">
          <div class="pp-panel-title">Calendario smart</div>
          <div class="pp-calendar">
            <div class="pp-day"><strong>EUR 92</strong><span>Lun</span></div>
            <div class="pp-day hot"><strong>EUR 118</strong><span>Ven</span></div>
            <div class="pp-day hot"><strong>EUR 124</strong><span>Sab</span></div>
            <div class="pp-day warn"><strong>EUR 140</strong><span>Evento</span></div>
            <div class="pp-day"><strong>EUR 88</strong><span>Mar</span></div>
            <div class="pp-day"><strong>EUR 96</strong><span>Mer</span></div>
            <div class="pp-day hot"><strong>EUR 110</strong><span>Domanda</span></div>
            <div class="pp-day"><strong>EUR 94</strong><span>Gio</span></div>
          </div>
        </div>
        <div class="pp-panel">
          <div class="pp-panel-title">Revenue forecast</div>
          <div class="pp-bars">
            <div class="pp-bar" style="height:48%"></div>
            <div class="pp-bar" style="height:68%"></div>
            <div class="pp-bar" style="height:55%"></div>
            <div class="pp-bar" style="height:82%"></div>
            <div class="pp-bar" style="height:72%"></div>
            <div class="pp-bar" style="height:94%"></div>
          </div>
        </div>
      </div>
      <div class="pp-kpi-row">
        <div class="pp-kpi"><b>+18%</b><span>ricavo stimato</span></div>
        <div class="pp-kpi"><b>12</b><span>competitor</span></div>
        <div class="pp-kpi"><b>6h</b><span>nuova analisi</span></div>
      </div>
    </div>
    """, unsafe_allow_html=True)


def _render_features_section():
    st.markdown('<span id="funzionalita"></span>', unsafe_allow_html=True)
    st.markdown(
        '<section class="pp-section"><h2>Funzionalita pensate per aumentare i ricavi</h2>'
        '<p class="pp-section-lead">Dalla raccomandazione manuale all autopilot completo: '
        'PricePilot ti aiuta a prendere decisioni rapide, motivate e controllate.</p></section>',
        unsafe_allow_html=True,
    )
    features = [
        ("P", "Pricing dinamico automatico", "Aggiorna le raccomandazioni in base a domanda, mercato e regole di sicurezza."),
        ("C", "Analisi competitor", "Confronta strutture simili e rileva quando sei sopra o sotto mercato."),
        ("K", "Calendario smart", "Visualizza prezzi consigliati, date bloccate, eventi e decisioni in attesa."),
        ("T", "Notifiche Telegram", "Ricevi motivazioni e approvazioni direttamente dove lavori ogni giorno."),
        ("O", "Ottimizzazione occupancy", "Bilancia prezzo e probabilita di prenotazione in base al contesto."),
        ("R", "Analytics revenue", "Leggi trend, storico decisioni e impatto stimato sui ricavi."),
        ("A", "Auto o approvazione", "Scegli tra consiglio, conferma manuale o autopilot controllato."),
        ("M", "Gestione multi proprieta", "Organizza piu appartamenti con regole e strategie coerenti."),
    ]
    for row in range(0, len(features), 4):
        cols = st.columns(4)
        for col, item in zip(cols, features[row:row + 4]):
            with col:
                _feature_card(*item)


def _feature_card(icon: str, title: str, desc: str):
    st.markdown(
        f'<div class="pp-card"><div class="pp-icon">{_html.escape(icon)}</div>'
        f'<h3>{_html.escape(title)}</h3><p>{_html.escape(desc)}</p></div>',
        unsafe_allow_html=True,
    )


def _render_how_it_works_section():
    st.markdown(
        '<section class="pp-section"><h2>Come funziona</h2>'
        '<p class="pp-section-lead">Un flusso semplice per partire in pochi minuti e lasciare '
        'che PricePilot lavori con regole chiare.</p></section>',
        unsafe_allow_html=True,
    )
    steps = [
        ("1", "Collega la proprieta", "Inserisci nome, piattaforma, zona e range prezzo della tua struttura."),
        ("2", "PricePilot analizza il mercato", "Il sistema valuta competitor, occupazione, weekend ed eventi rilevanti."),
        ("3", "Ottimizza automaticamente i prezzi", "Ricevi un consiglio, approvi da Telegram o lasci lavorare l autopilot."),
    ]
    cols = st.columns(3)
    for col, (num, title, desc) in zip(cols, steps):
        with col:
            st.markdown(
                f'<div class="pp-step"><div class="pp-step-num">{num}</div>'
                f'<h3>{_html.escape(title)}</h3><p>{_html.escape(desc)}</p></div>',
                unsafe_allow_html=True,
            )


def _render_pricing_section():
    st.markdown('<span id="prezzi"></span>', unsafe_allow_html=True)
    st.markdown(
        '<section class="pp-section"><h2>Piani semplici per ogni fase</h2>'
        '<p class="pp-section-lead">Parti gratis, passa all approvazione Telegram o attiva '
        'l autopilot completo quando sei pronto.</p></section>',
        unsafe_allow_html=True,
    )
    annual = st.toggle("Mostra prezzo annuale", value=False, key="public_pricing_annual")
    cols = st.columns(3)
    _pricing_card(cols[0], "free", "EUR 0", "Consigli motivati via Telegram. Aggiornamento manuale sulle OTA.", [
        "1 proprieta",
        "Analisi ogni 6 ore",
        "Suggerimenti prezzo motivati",
        "Calendario smart",
    ], "Inizia Gratis")
    plus_price = "EUR 23/mese" if annual else "EUR 29/mese"
    _pricing_card(cols[1], "plus", plus_price, "Approvi le modifiche da Telegram prima della sincronizzazione.", [
        "Fino a 5 proprieta",
        "Approvazione Telegram",
        "Guardrail avanzati",
        "Pronto per channel manager",
    ], "Scegli Plus", recommended=True)
    pro_price = "EUR 63/mese" if annual else "EUR 79/mese"
    _pricing_card(cols[2], "pro", pro_price, "Autopilot completo con report e notifiche operative.", [
        "Fino a 25 proprieta",
        "Autopilot controllato",
        "Report automatici",
        "Massima automazione",
    ], "Scegli Pro")


def _pricing_card(col, plan: str, price: str, desc: str, features: list[str], cta: str, recommended: bool = False):
    with col:
        badge = '<span class="pp-badge">Consigliato</span>' if recommended else ""
        feature_items = "".join(f"<li>{_html.escape(item)}</li>" for item in features)
        st.markdown(
            f'<div class="pp-price {"recommended" if recommended else ""}">{badge}'
            f'<div class="pp-price-name">{get_plan(plan)["label"]}</div>'
            f'<div class="pp-price-value">{_html.escape(price)}</div>'
            f'<div class="pp-price-desc">{_html.escape(desc)}</div>'
            f'<ul class="pp-feature-list">{feature_items}</ul></div>',
            unsafe_allow_html=True,
        )
        if st.button(cta, key=f"public_price_{plan}", use_container_width=True, type="primary" if recommended else "secondary"):
            _go_public("register", plan)


def _render_faq_section():
    st.markdown('<span id="faq"></span>', unsafe_allow_html=True)
    st.markdown(
        '<section class="pp-section"><h2>Domande frequenti</h2>'
        '<p class="pp-section-lead">Le basi per capire cosa succede prima di collegare integrazioni reali.</p></section>',
        unsafe_allow_html=True,
    )
    with st.expander("PricePilot cambia gia i prezzi sulle OTA?"):
        st.write("In demo prepara decisioni e flussi. La sincronizzazione reale arrivera con channel manager/API.")
    with st.expander("Posso usare PricePilot con una sola proprieta?"):
        st.write("Si. Il flusso e pensato sia per un singolo appartamento sia per portfolio piu grandi.")
    with st.expander("Il piano Free e davvero utilizzabile?"):
        st.write("Si: ricevi consigli motivati e aggiorni manualmente i prezzi sui canali.")
    with st.expander("Cosa fa il piano Plus?"):
        st.write("PricePilot propone il cambio prezzo e tu lo approvi prima dell applicazione.")


def _render_auth_panel(client, view: str):
    if st.button("Torna alla home", key="auth_back_home"):
        _go_public("landing")

    _, col, _ = st.columns([1, 1.25, 1])
    with col:
        plan = _selected_plan()
        st.markdown('<div class="pp-auth-wrap"><div class="pp-auth-card">', unsafe_allow_html=True)
        st.markdown(
            f'<span class="pp-plan-pill">Piano scelto: {get_plan(plan)["label"]}</span>'
            f'<div class="pp-auth-title">{_auth_title(view)}</div>'
            f'<div class="pp-auth-copy">{_auth_copy(view)}</div>',
            unsafe_allow_html=True,
        )

        if view == "login":
            login_email = st.text_input("Email", key="auth_login_email", placeholder="mario@esempio.it")
            login_pw = st.text_input("Password", key="auth_login_pw", type="password", placeholder="Password")
            if st.button("Accedi", key="auth_login_btn", use_container_width=True, type="primary"):
                _do_login(client, login_email, login_pw)
            c1, c2 = st.columns(2)
            with c1:
                if st.button("Crea account", key="auth_to_register", use_container_width=True):
                    _go_public("register")
            with c2:
                if st.button("Password dimenticata", key="auth_to_forgot", use_container_width=True):
                    _go_public("forgot")

        elif view == "forgot":
            reset_email = st.text_input("Email", key="auth_forgot_email", placeholder="mario@esempio.it")
            if st.button("Invia link di recupero", key="auth_forgot_btn", use_container_width=True, type="primary"):
                _do_password_reset(client, reset_email)
            if st.button("Torna al login", key="forgot_to_login", use_container_width=True):
                _go_public("login")

        else:
            signup_email = st.text_input("Email", key="auth_signup_email", placeholder="mario@esempio.it")
            signup_name = st.text_input("Nome attivita", key="auth_signup_account_name", placeholder="Es. Rossi Apartments")
            selected_plan = st.selectbox(
                "Piano scelto",
                list(PLAN_ORDER),
                index=list(PLAN_ORDER).index(plan),
                format_func=lambda p: get_plan(p)["label"],
                key="auth_signup_plan",
            )
            st.session_state[_KEY_SELECTED_PLAN] = selected_plan
            signup_pw = st.text_input(
                "Password",
                key="auth_signup_pw",
                type="password",
                placeholder="Minimo 6 caratteri",
            )
            if st.button("Crea account", key="auth_signup_btn", use_container_width=True, type="primary"):
                _do_signup(client, signup_email, signup_pw, signup_name, selected_plan)
            if st.button("Hai gia un account? Accedi", key="register_to_login", use_container_width=True):
                _go_public("login")

        auth_label = "Supabase" if client else "locale"
        st.caption(f"Auth {auth_label}. Dopo la registrazione entrerai nell onboarding iniziale.")
        st.markdown("</div></div>", unsafe_allow_html=True)


def _auth_title(view: str) -> str:
    return {
        "login": "Accedi alla dashboard",
        "forgot": "Recupera password",
        "register": "Crea il tuo account",
    }.get(view, "Crea il tuo account")


def _auth_copy(view: str) -> str:
    return {
        "login": "Bentornato. Entra nella dashboard per gestire proprieta, decisioni e prezzi.",
        "forgot": "Inserisci la tua email. Con Supabase collegato riceverai il link di recupero.",
        "register": "Scegli il piano, crea l account e completa il setup della prima proprieta.",
    }.get(view, "")


def _do_login(client, email: str, password: str):
    email = (email or "").strip().lower()
    password = (password or "").strip()
    if not email or not password:
        st.error("Inserisci email e password.")
        return
    if client is None:
        _do_local_login(email, password)
        return
    try:
        resp = client.auth.sign_in_with_password({"email": email, "password": password})
        _store_supabase_session(resp)
        st.success("Accesso effettuato.")
        st.rerun()
    except Exception as exc:
        _handle_auth_error(exc, context="login")


def _do_signup(client, email: str, password: str, account_name: str = "", plan: str = "free"):
    email = (email or "").strip().lower()
    password = (password or "").strip()
    if not email or not password:
        st.error("Inserisci email e password.")
        return
    if len(password) < 6:
        st.error("La password deve avere almeno 6 caratteri.")
        return
    if client is None:
        _do_local_signup(email, password, account_name, plan)
        return
    try:
        resp = client.auth.sign_up({"email": email, "password": password})
        user = getattr(resp, "user", None)
        if user and getattr(user, "id", None):
            _store_supabase_session(resp)
            st.success("Account creato.")
            st.rerun()
        else:
            st.info("Registrazione completata. Controlla la email e poi accedi.")
    except Exception as exc:
        _handle_auth_error(exc, context="registrazione")


def _store_supabase_session(resp):
    user = getattr(resp, "user", None)
    session = getattr(resp, "session", None)
    if user:
        local_user = _ensure_external_user(
            email=getattr(user, "email", ""),
            external_user_id=getattr(user, "id", ""),
            plan=_selected_plan(),
        )
        _set_local_session(local_user)
    if session:
        st.session_state[_KEY_SESSION] = session


def _hash_password(password: str) -> str:
    iterations = 210_000
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        iterations,
    ).hex()
    return f"pbkdf2_sha256${iterations}${salt}${digest}"


def _verify_password(password: str, stored: str) -> bool:
    try:
        algorithm, iterations, salt, expected = (stored or "").split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            int(iterations),
        ).hex()
        return secrets.compare_digest(digest, expected)
    except Exception:
        return False


def _set_local_session(user: dict | None):
    if not user:
        return
    st.session_state[_KEY_USER] = {
        "id": int(user["id"]),
        "email": user.get("email", ""),
        "account_id": int(user.get("account_id") or 1),
        "role": user.get("role", "owner"),
    }


def _do_local_login(email: str, password: str):
    user = get_user_by_email(email)
    if not user or not _verify_password(password, user.get("password_hash", "")):
        st.error("Email o password non corretti.")
        return
    update_user(int(user["id"]), {"last_login_at": datetime.utcnow().isoformat()})
    _set_local_session(user)
    st.success("Accesso effettuato.")
    st.rerun()


def _do_local_signup(email: str, password: str, account_name: str = "", plan: str = "free"):
    try:
        result = create_account_owner(
            email=email,
            password_hash=_hash_password(password),
            account_name=account_name or "La mia attivita",
            plan=plan,
        )
        _set_local_session(result["user"])
        st.success("Account creato. Benvenuto in PricePilot.")
        st.rerun()
    except ValueError as exc:
        st.error(str(exc))
    except Exception as exc:
        st.error(f"Errore durante la registrazione: {exc}")


def _ensure_external_user(email: str, external_user_id: str = "", plan: str = "free") -> dict | None:
    email = (email or "").strip().lower()
    if not email:
        return None
    existing = get_user_by_email(email)
    if existing:
        update_user(int(existing["id"]), {
            "auth_provider": "supabase",
            "external_user_id": external_user_id,
            "last_login_at": datetime.utcnow().isoformat(),
        })
        return get_user_by_email(email)

    account = create_account("La mia attivita", plan=normalize_plan(plan), billing_status="dev")
    user = create_user(
        int(account["id"]),
        email=email,
        role="owner",
        full_name="",
    )
    update_user(int(user["id"]), {
        "auth_provider": "supabase",
        "external_user_id": external_user_id,
        "last_login_at": datetime.utcnow().isoformat(),
    })
    return get_user_by_email(email)


def _do_password_reset(client, email: str):
    email = (email or "").strip().lower()
    if not email:
        st.error("Inserisci la tua email.")
        return
    if client is None:
        st.info("Recupero password email disponibile quando collegheremo Supabase/SMTP. In locale puoi creare un nuovo account di test.")
        return
    try:
        client.auth.reset_password_email(email)
        st.success("Ti abbiamo inviato il link di recupero password.")
    except Exception as exc:
        _handle_auth_error(exc, context="recupero password")


def _handle_auth_error(exc: Exception, context: str = ""):
    msg = str(exc).lower()
    if "invalid login" in msg or "invalid credentials" in msg:
        st.error("Email o password non corretti.")
    elif "email not confirmed" in msg:
        st.warning("Conferma la tua email prima di accedere.")
    elif "already registered" in msg:
        st.error("Esiste gia un account con questa email. Usa Accedi.")
    elif "rate limit" in msg:
        st.error("Troppi tentativi. Riprova tra qualche minuto.")
    else:
        st.error(f"Errore durante la {context}: {exc}")
